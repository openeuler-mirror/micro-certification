# Angle

An example project to calculate angle

## Install

Run the following commands to build and install the project:

```
mkdir build && cd build
../configure
make && make install
```

## Usage

Simply run 

`angle`
