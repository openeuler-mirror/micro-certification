#include <stdio.h>
#include <math.h>

#define pi 3.14159

float sin_angle;

void sin_value(void)
{
    float value;
    value = sin(sin_angle / 180. * pi);
    printf("\nThe Sin is: %5.2f\n",value);
}
